<?php $page_title = 'Thank you! Appliction Sent successfully'; ?>
<?php include('../private/initials.php');?>
<?php include(PRIVATE_PATH.'/classes/Database.php');?>
<?php include(SHARED_PATH.'/header.php');?>

<style type="text/css">
.my_main{
    box-shadow: none;
}
</style>
<?php
	// the message
	$first_name  = $_POST["firstName"];
	$last_name   = $_POST["lastName"];
	$email      = $_POST["email"];
if(!isset($first_name) || !isset($last_name) || !isset($email)){
?>
<div class="alert alert-danger">
          <strong>Sorry!</strong> Something went wrong! Try Again!!.
          <p>

              <?php
                  echo "ERROR: ". mysqli_error($conn);
              ?>
          </p>
      </div>
<?php

  die();
}
$db = new Database();
$conn = $db->db_connect();
$candidate = new Candidate();
$flag = $candidate->add($conn, $first_name, $last_name, $email);

	if ($flag) {
        //$last_id = mysqli_insert_id($conn);
        ?>

        <div class="alert alert-success text-center">
            <strong>Thank you!</strong> Your application has been sent successfully! We will contact your soon.
        </div>
	<?php
	}else{?>

	 	<div class="alert alert-danger">
	            <strong>Sorry!</strong> Something went wrong! Try Again!!.
	            <p>

	                <?php
	                    echo "ERROR: ". mysqli_error($conn);
	                ?>
	            </p>
	        </div>
	<?php }



?>

		<h3>Dear RBK Applicant,</h3>

		<p>
			In order to complete your application to RBK, please complete the following steps. We recommend that you allow 4 hours to complete the full application. Please note that no preparation is needed for any of these assessments.
		</p>
		<ol>
			<li>
				<a href="https://docs.google.com/forms/d/e/1FAIpQLSe623aE0_DlgeASd-sUniUhYw1cAcxeK6KBALkMSl4Abz2weA/viewform" target="_blank"> Biographic Information & RBK Commitment Agreement</a>
			</li>
			<li><a href="https://docs.google.com/forms/d/16UWgv7ke7gHaFULt106gjFv2CPh6R1tfdA5QhzQSOb8/edit" target="_blank">Mindset Assessment</a>
			</li>
			<li>
				<a href="https://docs.google.com/forms/d/1HFIFvo9MGQ1TaJP8joRIX_YjsQYoWBMXc_i2L9mvPRk/edit" target="_blank">Analytic Assessment</a>
			</li>
		</ol>
			<p>Good luck and let's get started! </p><br>
<?php include SHARED_PATH.'/footer.php'; ?>
