<?php include('../private/initials.php');?>
<?php include(SHARED_PATH . '/functions.php'); ?>
<?php include(SHARED_PATH . '/header.php');?>

<style type="text/css">
.my_main{
    box-shadow: none;
}
</style>
<div>
        <h1> Instructions </h1>
        <h4>Dear RBK Applicant,</h4>

<p>Thank you for creating your RBK account. Please READ all of the following instructions before you press <b>NEXT</b>.</p>
<ol>
    <li>The Admissions Application consists of the following:</li>
    <ul>
        <li>Biographic Information and Commitment Agreement</li>
        <li>Mindset Assessment</li>
        <li>Analytical Assessment</li>
    </ul>
    <p>Please allow up to 4 hours to complete the Application. No preparation is required.</p>
    <li>RBK Admissions Team communicates via email, so please monitor your email account closely.</li>
    <li>Your application will not be considered if you don't fully complete the Application.</li>
    <li>Within 2 weeks of completing your Application, you will be notified of your admission status. Either you will be invited to continue the admissions process or your will invited to apply to the next cohort and provided materials to better prepare you.</li>
    <li>Applicants invited to continue with the admissions process will be given an online assignment. The assignment must be completed within 3 weeks from the day the assignment is issued so please check your email daily. Applicants without access to a laptop or desktop computer are welcome to complete the assignment at RBK's Khalda campus.</li>
    <li>If you have any issues with your account, please contact us by email: <a href="admissions@rbk.org">admissions@rbk.org</a>.</li>
</ul>

<br>
<p><b>RBK Admissions Team</b></p>

        <button class="btn btn-sample navbar-btn navbar-right" onclick="changeURL('query.php');"> Next</button>


</div>
<?php include SHARED_PATH.'/footer.php'; ?>
