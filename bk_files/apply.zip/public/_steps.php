<?php include('../private/initials.php');?>
<?php include SHARED_PATH.'/functions.php'; ?>
<?php //include SHARED_PATH.'/header.php'; ?>
<style type="text/css">
.my_main{
    box-shadow: none;
}
</style>
<div>
        <h1> Steps </h1>

        <button class="btn btn-sample navbar-btn navbar-right" onclick="changeURL('instructions.php');"> Next</button>

</div>
<?php include SHARED_PATH.'/footer.php'; ?>
