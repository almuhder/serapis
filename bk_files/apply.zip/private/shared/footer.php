    </div>


    <div class="contianer-fluid footer navbar-fixed-bottom">
        <p class="text-center">Serapis 2019 © All Rights Reserved</p>
    </div>



    <!-- Libraries-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.5/validator.min.js"></script>

    <script>
        function changeURL($url){
            console.log($url);
            window.location.href=$url;
        }

        // function checkWidth(init) {
        //     if ($(window).width() < 768) {
        //         $('#submitButton').addClass('btn-block');
        //         $('#applyButton').removeClass('navbar-right');
        //         $('#applyButton').addClass('btn-block');
        //     } else {
        //         if (!init)
        //             $('#submitButton').removeClass('form-control');
        //             $('#applyButton').addClass('navbar-right');
        //             $('#applyButton').removeClass('btn-block');
        //             $('#submitButton').removeClass('btn-block');
        //     }
        // }
        // $(document).ready(function() {
        //     checkWidth(true);
        //     $(window).resize(function() {
        //         checkWidth(false);
        //     });
        // });
    </script>
</body>

</html>
