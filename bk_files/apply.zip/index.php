<?php
    //header("Location: http://rbk.org/apply/public/index.php"); 
    $url = "http://serapis.rbk.org/register/public";
    header($url);
    exit();
?>
