<?php
    // Database Infomation
    // Remote
    define("SERVER", "localhost");
    define("DB_NAME", "rbk15109_serapis");
    define("DB_PASSWORD", "]fBNvx)TKJE$");
    define("DB_USERNAME", "rbk15109_serapis");
?>
