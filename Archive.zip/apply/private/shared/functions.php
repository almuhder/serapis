<?php //sinclude 'config.php'; ?>
<?php
// function connectDatabase(){
//     $conn = mysqli_connect(SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
//     // Check connection
//     if (mysqli_connect_error()) {
//         die("Database connection failed: " . mysqli_connect_error());
//     }
// }
//
// function insert($sql){
//     if (mysqli_query($conn, $sql)) {
//         $last_id = mysqli_insert_id($conn);
//         echo "New record created successfully. Last inserted ID is: " . $last_id;
//     } else {
//         echo "Error: " . $sql . "<br>" . mysqli_error($conn);
//     }
// }

// function redirectPage($url){
//     header("Location: ".$url);
// }


// function db_escape($link, $value){
//   return mysqli_real_escape_string($link,$value);
// }

// function closeConnection(){
//     mysqli_close($conn);
// }
?>
