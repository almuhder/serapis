<?php include('../private/initials.php');?>
<?php include(SHARED_PATH . '/functions.php'); ?>
<?php include(SHARED_PATH . '/header.php');?>

<style type="text/css">
.my_main{
    box-shadow: none;
}
</style>
<div>
        <h1> Instructions </h1>

        <img class="img img-responsive" src="http://serapisrbk.com/beta/apply/public/_images/rbk-admissions.png">
        <br>
        <h4>Dear RBK Applicant,</h4>

<p>In order to complete your application to RBK, please complete the following steps. Please note that no preparation is needed for this assessment. ( You can get the links of assessment & Biographic info and commitment agreement from To Do document, and you have access ) 

</p>

<br>
<p><b>RBK Admissions Team</b></p>

        <button class="btn btn-sample navbar-btn navbar-right" onclick="changeURL('query.php');"> Next</button>


</div>
<?php include SHARED_PATH.'/footer.php'; ?>
